# HIERARCHIA-ZRODEL.md — Kanoniczna Kategoryzacja Źródeł (RZĄD 1/2/3)

> **Plik:** `shared/HIERARCHIA-ZRODEL.md`
> **Wersja:** 1.11 (2026-09-23c) — E-3 uruchamia BRAK-AKTU (akt niepobieralny z RZĘDU 1: awaria serwera, timeout, blokada) — wtedy obowiązkowo; przy awarii ELI próba odczytu z ISAP.
> **Wersja poprzednia:** 1.10 (2026-09-23) — ⭐ KANON KOLEJNOŚCI E-1…E-5 dla aktów polskich: ELI pierwszy, ISAP wyłącznie adres dla człowieka, LEX/Legalis → ArsLege dopiero po porażce ELI w obu kanałach; reguła interpretacyjna „ISAP” w pozostałych plikach; RZĄD 1 przeuporządkowany.
> **Wersja poprzednia:** 1.9 (2026-09-14) — CBOSA: oddzielono provenance kanału (DIRECT_LIVE / CRAWLED_OR_INDEXED) od kanonicznego statusu weryfikacji; snapshot może nieść sentencję/uzasadnienie, ale nie tworzy piątego statusu i nie awansuje sam do ✅ [VER].
> **Wersja poprzednia:** 1.8 (2026-09-14) — RZĄD 2A orzecznictwa powiązany z kanonicznym
>              routingiem wykonawczym: SN / Portal Orzeczeń / CBOSA / SAOS.
>              Dla NSA/WSA direct CBOSA (formularz HTML + /doc/{ID}) jest
>              preferowany po fresh-probe; fallback indeksowy dopiero przy
>              niedostępności. Exact-match i fail-closed są obowiązkowe.
> **Wersja poprzednia:** 1.7 (2026-09-04) — REALIA DOSTĘPNOŚCI uzupełnione o wymogi
>              kształtu żądania w kanale kodu (F-157); potwierdzone API UODO
>              jako pierwszy maszynowy kanał orzeczniczy po stronie organu (F-158).
>              ⛔ Numer skorygowany z 1.6 na 1.7 — 1.6 była już zajęta przez
>              wpis z 2026-09-01f; kolizja wykryta 2026-09-04c.
> **Wersja:** 1.6 (2026-09-01f) — uzupełnienie LUK PUBLIKATORÓW. RZĄD 1:
>              dodano Monitor Polski, Dziennik Ustaw RCL, dzienniki urzędowe
>              ministrów i urzędów centralnych oraz wojewódzkie dzienniki
>              urzędowe — jedyny publikator aktów prawa miejscowego, bez
>              którego DR-08 i DR-09 nie miały skąd wziąć brzmienia uchwały
>              czy planu miejscowego. RZĄD 2A: interpretacje organów
>              (EUREKA, BIP GIP — art. 14b ustawy o PIP), rejestry urzędowe
>              i publikatory ogłoszeń (KRS, KRZ, EKW, CEIDG, REGON, SUDOP,
>              BZP) oraz materiały legislacyjne (RCL, druki sejmowe) —
>              te ostatnie z zakazem cytowania brzmienia.
> **Wersja:** 1.5 (2026-09-01c) — korekta sekcji REALIA DOSTĘPNOŚCI RZĘDU 1
>              (F-151): rozdzielono blokadę narzędzia od zakazu serwera,
>              dodano kolumnę kanału kodu, dopisano odesłanie do pułapki
>              `/text.html` (F-150) oraz nowy RZĄD 2A dla orzecznictwa
>              organów (UODO, KIO, UKE) z jawnym statusem dostępu.
> **Wersja:** 1.4 (2026-08-23) — dodano `eli.gov.pl` do RZĘDU 1 (nie było go
>              tam mimo urzędowego charakteru), sekcję REALIA DOSTĘPNOŚCI
>              RZĘDU 1 (moc źródła ≠ osiągalność źródła), zamknięcie
>              hierarchii statusów na czterech pozycjach oraz ostrzeżenie
>              o wersjach archiwalnych na portalach 2B. Wdrożone po analizie
>              przyczyn testu 3 pilotażu LEX MACHINA.
> **Wersja:** 1.3 (2026-07-24e) — dodano ZASADĘ OTWARTEJ LISTY w sekcji
>              Rzędu 3: brak wpisu domeny w tym pliku lub w
>              `PORTALE-BRANZOWE-RZAD-2B.md` nie blokuje cytowania —
>              rejestry są przykładowe/pomocnicze, nie zamkniętą listą
>              dopuszczonych źródeł. Na wyraźne polecenie użytkownika.
> **Wersja:** 1.2 (2026-07-24) — rozdzielono sekcję 3B na 3B-i
>              (nieustalone/inne wydawnictwo → Rząd 3) i 3B-ii
>              (jednoznacznie C.H.Beck/Wolters Kluwer w próbce →
>              Rząd 2B-równoważne, dziedziczony po marce wydawniczej już
>              uznanej w 2B przez legalis.pl/lex.pl), na uwagę
>              użytkownika. Dodano wymóg sprawdzenia aktualności wydania
>              względem nowelizacji (książka nie jest aktualizowana jak
>              portal).
> **Wersja:** 1.1 (2026-07-24) — dodano sekcję 3B: próbki/fragmenty
>              książek z księgarni cyfrowych (nexto.pl i analogiczne), na
>              wyraźne polecenie użytkownika. Odróżnia legalne, wydawniczo
>              udostępnione PRÓBKI (spis treści + fragment stron) od
>              flagi F-12 (pełne, nieautoryzowane pliki PDF) w
>              `audyt-systemu-v4/references/WARN-OTWARTE.md`.
> **Wersja:** 1.0 (2026-07-15) — wydzielone z `analizator-przepisow-v2/SKILL.md`
>              (Moduł 1, sekcja "Hierarchia źródeł") na kanoniczną lokalizację
>              współdzieloną, na wyraźne polecenie użytkownika po tym, jak
>              w rozmowie ujawniono, że kategoryzacja obowiązywała TYLKO
>              lokalnie w jednym skillu i nie była wymuszana przy linkach/
>              kotwicach generowanych poza tym skillem (np. w WERYFIKACJA-SLAD,
>              PRAWO-HARDGATE, dowolnym web_search poza kontekstem analizy
>              przepisu).
> **Status:** KANONICZNY — konsumenci: `analizator-przepisow-v2` (Moduł 1),
>              `shared/PRAWO-HARDGATE.md` (KROK 5/5A/5B, BRAMKA WTÓRNE-
>              ŹRÓDŁO-STOP), `shared/WERYFIKACJA-SLAD.md` (KOTWICA-TEKSTOWA,
>              tabela statusów śladu) — oraz KAŻDY inny skill/moduł, który
>              podaje użytkownikowi link/URL/kotwicę do źródła internetowego.
> **Zasada dedup:** to jest JEDYNA kanoniczna treść tej kategoryzacji.
>              Żaden inny plik nie powiela tej listy — odwołuje się tutaj.

---

## ZASADA NACZELNA

> ⛔ **OBOWIĄZEK KATEGORYZACJI** — każdy link/URL/kotwica podana użytkownikowi
> jako źródło (przepis, orzeczenie, komentarz, artykuł, blog, portal) MUSI
> mieć przypisaną kategorię RZĄD 1 / RZĄD 2A / RZĄD 2B / RZĄD 3 — niezależnie
> od tego, w którym skillu/module powstaje odpowiedź. Brak kategoryzacji przy
> podaniu linku jest błędem tego samego rzędu co brak znacznika ✅ [VER] /
> ⚠️ [NIEWERYFIKOWANE] z `shared/WERYFIKACJA-SLAD.md` — te dwa mechanizmy
> działają RAZEM (jeden mówi CZY zweryfikowano, drugi mówi JAK WIARYGODNE
> jest źródło samo w sobie).

---

## ⭐ KANON KOLEJNOŚCI — AKTY POLSKIE (od v1.10, 2026-09-23) — NADRZĘDNY

To jest **jedyne** miejsce, które ustala kolejność źródeł dla brzmienia i stanu
aktów polskich. Każdy inny plik systemu (router, fasada, DR-01…DR-16, pisma,
analizy, audyt) odsyła tutaj. Przy sprzeczności wygrywa ten kanon.

```
E-1  ELI — RZĄD 1, KANAŁ PODSTAWOWY
     api.sejm.gov.pl/eli (kanał kodu: curl/skrypt, neutralny UA — shared/DOSTEP-MASZYNOWY-API.md §1)
       /eli/acts/search?title=…        → rok i pozycja aktualnego t.j.
       /eli/acts/DU/{rok}/{poz}        → metryka, status, daty
       /eli/acts/DU/{rok}/{poz}/text.pdf → BRZMIENIE (t.j.; pułapka /text.html — B-T1…B-T3 PRAWO-HARDGATE)
       /eli/acts/DU/{rok}/{poz}/references → zmiany po t.j.
     → eli.gov.pl → dziennikustaw.gov.pl / monitorpolski.gov.pl (ten sam publikator)
     Host bez kanału kodu: sekwencja B-1 → B-2 (PRAWO-HARDGATE).
     Znacznik: ✅ [VER: ELI DU/RRRR/NNN, data]

E-2  ISAP — ADRES DLA CZŁOWIEKA
     isap.sejm.gov.pl: link podawany czytelnikowi obok ELI, pomocnicza
     identyfikacja aktu; przy awarii ELI — próba odczytu treści z ISAP.
     Sama niedostępność ISAP przy działającym ELI nie uruchamia E-3
     (akt został pobrany).

E-3  LEX / Legalis — RZĄD 2A (tekst przy uprawnionym dostępie)
     Uruchamia go BRAK-AKTU: aktu nie da się pobrać z RZĘDU 1 — ani z ELI
     (każdym kanałem dostępnym w hoście), ani z ISAP / dziennikustaw.gov.pl —
     z jakiejkolwiek przyczyny: awaria lub przeciążenie serwera, timeout,
     blokada, brak kanału w hoście. Wynik prób zapisz w śladzie. Bez tej
     ścieżki nie byłoby żadnej weryfikacji — dlatego jest obowiązkowa, a nie
     opcjonalna. Nie zakładaj, że użytkownik ma licencję.

E-4  ArsLege i inne serwisy tekstów — RZĄD 2B
     Gdy E-3 niedostępne. Status wyłącznie 🟨 [KOTWICA-URZĘDOWA] na warunkach
     K-1…K-4 z PRAWO-HARDGATE; bez nich jawny zakres nieweryfikowany.

E-5  Wszystko zawiodło → ⚠️ [NIEWERYFIKOWANE]; zakaz cytowania z pamięci.
```

⛔ 🟨 i RZĄD 2B są **niedopuszczalne**, gdy E-1 dał treść. Zejście do E-3/E-4
bez zapisanego BRAKU-AKTU w RZĘDZIE 1 = naruszenie HARD GATE.
⛔ Odwrotnie: przy BRAKU-AKTU pominięcie E-3/E-4 i od razu ⚠️ też jest błędem —
najpierw wyczerp źródła zastępcze.

⛔ **REGUŁA INTERPRETACYJNA „ISAP”.** W każdym pliku systemu zwroty typu
„weryfikuj w ISAP”, „ISAP każdy przepis”, „weryfikacja ISAP”, „pobierz z ISAP”,
„✅ [VER: ISAP, …]” w **instrukcjach** oznaczają: „zweryfikuj w RZĘDZIE 1 według
E-1…E-5”, czyli najpierw ELI. Wpisy **historyczne** („zweryfikowano w ISAP
2026-06-05”) opisują przeszłość i nie są instrukcją — nie przepisuj ich.

---

## RZĄD 1 — PIERWSZORZĘDNE (wiążące, wyłączne dla BRZMIENIA przepisu)

Kolejność użycia — KANON E-1…E-5 wyżej. Lista mocy źródeł:

1. **API ELI Sejm — https://api.sejm.gov.pl/eli/...** — PRIORYTET: brzmienie
   (`text.pdf` t.j.), metryka, status, zmiany (warstwa strukturalna,
   `shared/PRAWO-HARDGATE.md` POZIOM B).
2. **ELI / Dziennik Ustaw — https://eli.gov.pl** (dodane 2026-08-23, v1.4) —
   urzędowy portal European Legislation Identifier prowadzony dla Dz.U.;
   często SZYBSZY w indeksacji nowych t.j. niż ISAP.
   Wzorzec adresu: `eli.gov.pl/eli/DU/{rok}/{poz}` (metryka),
   `.../text.html`, `.../text.pdf` (treść).
3. ISAP — https://isap.sejm.gov.pl — ta sama moc co ELI, ale rola od v1.10:
   **adres dla człowieka** i pomocnicza identyfikacja (E-2). Nie jest kanałem
   odczytu treści dla modelu.
4. Sejm RP — https://www.sejm.gov.pl/prawo/prawo.htm
5. EUR-Lex — https://eur-lex.europa.eu — prawo UE implementowane w Polsce
6. UODO — https://uodo.gov.pl — przepisy o ochronie danych
7. BIP właściwego organu — dla rozporządzeń branżowych
8. **Monitor Polski** (dodane 2026-09-01f) — urzędowy publikator uchwał,
   obwieszczeń i zarządzeń: `monitorpolski.gov.pl` (RCL) oraz warstwa
   strukturalna `api.sejm.gov.pl/eli/acts/MP/{rok}/{poz}`. ⛔ System miał
   dotąd wpiętą wyłącznie ścieżkę Dz.U.; M.P. był publikatorem RZĘDU 1
   nieobecnym w tej liście, mimo że rozstrzyga o obwieszczeniach i uchwałach
   powoływanych w sprawach administracyjnych.
9. **Dziennik Ustaw — RCL** — `dziennikustaw.gov.pl`; ten sam publikator co
   ISAP/ELI, inny gospodarz serwisu. Przydatny, gdy pozostałe kanały zawodzą.
10. **Dzienniki urzędowe ministrów i urzędów centralnych** —
    `dziennikiurzedowe.gov.pl` (indeks centralny).
11. **Wojewódzkie dzienniki urzędowe** — portal zbiorczy RCL:
    `dziennikiurzedowe.gov.pl` (dawniej `dziennikiurzedowe.rcl.gov.pl`).
    ⛔ To JEDYNY publikator **aktów prawa miejscowego** — uchwał rady gminy,
    zarządzeń wójta, planów miejscowych. Bez niego DR-08 (samorząd) i DR-09
    (planowanie i budownictwo) nie mają skąd wziąć brzmienia aktu, na którym
    opiera się rozstrzygnięcie.
    ⛔⛔ Serwisy poszczególnych województw NIE mają jednolitego wzorca adresu.
    Zmierzone przykłady: `edziennik.malopolska.uw.gov.pl`,
    `e-dziennik.szczecin.uw.gov.pl` (inna forma zapisu), mazowieckie —
    wejście przez `gov.pl/web/uw-mazowiecki`. Adresu NIE buduj z szablonu;
    wejdź przez portal zbiorczy i weź link stamtąd. (Korekta 2026-09-01g:
    v1.6 podawała szablon `edziennik.{województwo}.uw.gov.pl` — nieprawdziwy.)
    ⚠️ Publikatory wojewódzkie NIE są objęte API ELI Sejmu (zmierzone
    2026-09-01: `api.sejm.gov.pl/eli/acts` zwraca wyłącznie `DU` i `MP`).

### ⛔ REALIA DOSTĘPNOŚCI RZĘDU 1 (v1.4 2026-08-23, skorygowane v1.5 2026-09-01c,
### uzupełnione v1.7 2026-09-04 o wymogi kształtu żądania — F-157)

Przynależność do RZĘDU 1 mówi o **mocy** źródła, nie o jego **osiągalności**.
Osiągalność zależy od KANAŁU, którym host sięga po sieć — i to jest korekta
wprowadzona przez flagę F-151, bo wersja 1.4 opisywała jeden kanał tak, jakby
był jedynym.

| Kanał hosta | ISAP | eli.gov.pl | api.sejm.gov.pl |
|---|---|---|---|
| `web_fetch` | ROBOTS_DISALLOWED; nadto pętla 302 | ROBOTS_DISALLOWED (decyzja narzędzia — serwer nie zakazuje) | odrzuca URL konstruowany (PERMISSIONS_ERROR) |
| wykonanie kodu z siecią (`curl`/skrypt) | pętla 302 — **kanał martwy** | HTTP 200 | HTTP 200, pełne API |

⛔ Zmierzone 2026-09-01: `eli.gov.pl/robots.txt` brzmi `User-Agent: * /
Disallow:` — czyli **zezwala na wszystko**. Blokada `web_fetch` nie jest
zakazem serwera i nie wolno jej opisywać jako właściwości źródła.

⛔⛔ **Kanał kodu ma własne wymogi (F-157, 2026-09-04).** Wiersz „HTTP 200"
w tabeli wyżej obowiązuje **tylko dla żądania o właściwym kształcie**:
neutralny `User-Agent` (`curl/8.5.0` lub brak — **nie** łańcuch
przeglądarkowy), nagłówek `Accept`, ścieżka robocza zamiast roota.
Pominięcie któregokolwiek daje objaw nieodróżnialny od awarii źródła:
`orzeczenia.ms.gov.pl` oddaje 200 pod `curl` i **502** pod Chrome (5/5),
a SAOS bez `Accept` odpowiada **406**. ⚠️ Najgroźniejszy wariant to
**HTTP 200 ze stroną zastępczą** — sprawdzaj treść, nie kod odpowiedzi.
Pełna procedura: `shared/PRAWO-HARDGATE.md`, blok „KANAŁ KODU MA WŁASNE
WYMOGI"; konkretne endpointy i ich wymogi: `shared/DOSTEP-MASZYNOWY-API.md`. ⛔ Nie wolno na tej podstawie orzec, że źródło RZĘDU 1 jest
niedostępne, dopóki nie sprawdzono kształtu żądania.

| Co chcesz ustalić | Osiągalne z RZĘDU 1? |
|---|---|
| Tożsamość aktu, numer i data aktualnego t.j., status obowiązywania | **TAK** — snippet ISAP/ELI wystarcza w każdym kanale |
| Dosłowne BRZMIENIE artykułu — host BEZ kanału kodu | **NIE** — zejście na RZĄD 2B + 🟨 KOTWICA URZĘDOWA |
| Dosłowne BRZMIENIE artykułu — host Z kanałem kodu | **TAK** — `api.sejm.gov.pl` → t.j. → `text.pdf`; kotwica urzędowa NIEUZASADNIONA |

⛔ Przy odczycie treści z API obowiązuje sekwencja B-T1…B-T3 z
`shared/PRAWO-HARDGATE.md` (pułapka `/text.html` = tekst ogłoszony, F-150).
Sam fakt pobrania z domeny RZĘDU 1 nie dowodzi, że pobrano wersję aktualną.

⛔ To NIE otwiera drogi do cytowania z pamięci. Otwiera drogę do jednego,
ściśle opisanego statusu zastępczego — `shared/PRAWO-HARDGATE.md`, sekcja
„🟨 KOTWICA URZĘDOWA", warunki łączne K-1…K-4. Hierarchia statusów jest
zamknięta i liczy cztery pozycje:
`✅ [VER]` > `🟨 [KOTWICA-URZĘDOWA]` > `⚠️ [NIEWERYFIKOWANE]` > `⬛ [DO UZUPEŁNIENIA]`.
Tworzenie piątej etykiety jest naruszeniem hard gate.

Ten rząd dotyczy WYŁĄCZNIE brzmienia przepisu — obowiązuje tu
`shared/PRAWO-HARDGATE.md` bez wyjątków.

## RZĄD 2 — DRUGORZĘDNE

⭐ UZUPEŁNIENIE (dodane 2026-07-21): dla wyboru KONKRETNEGO portalu wg
TEMATYKI/DZIEDZINY (nie tylko wg wiarygodności) → `shared/PORTALE-
BRANZOWE-RZAD-2B.md` — rejestr portali PODZIELONY wg 16 dziedzin DR, z
WYNIKAMI faktycznych testów `site:` (np. gofin.pl dla podatków,
rynekzdrowia.pl dla zdrowia/farmacji, prawniknabudowie.com dla sporów
budowlanych). TEN plik (HIERARCHIA-ZRODEL) POZOSTAJE kanoniczny dla
KATEGORYZACJI wiarygodności (Rząd 1/2A/2B/3) — tamten UZUPEŁNIA o
wymiar tematyczny, nie zastępuje tej kategoryzacji.

Oficjalne orzecznictwo, LEX/Legalis jako tekst przy licencji, ORAZ duże,
uznane portale prawnicze/branżowe (komentarz i interpretacja o niskim
ryzyku dezaktualizacji, redakcja profesjonalna).

**2A — oficjalne, wykonawcze/orzecznicze (znacznik ✅ [VER: ...]):**
- **Orzecznictwo z oficjalnych baz sądowych — RZĄD 2A dla treści
  rozstrzygnięcia**: `sn.pl`, `orzeczenia.ms.gov.pl`,
  `orzeczenia.nsa.gov.pl` (CBOSA), `trybunal.gov.pl` /
  `ipo.trybunal.gov.pl`; `saos.org.pl` wyłącznie pomocniczo / jako kontrola
  krzyżowa. Orzeczenie NIE jest źródłem brzmienia przepisu, więc nie awansuje
  do RZĘDU 1; RZĄD 2A oznacza tu autentyczne źródło rozstrzygnięcia.
  
  **Routing wykonawczy jest obowiązkowy i nie wolno zastępować go dowolnym
  web_search:** 
  
  | Rodzina | Źródło rozstrzygające | Kanał / mechanizm |
  |---|---|---|
  | SN | `sn.pl` | `shared/DOSTEP-MASZYNOWY-API.md` + `shared/SYGNATURY.md`; `snproxy` JSON po świeżym pomiarze runtime |
  | SR/SO/SA | `orzeczenia.ms.gov.pl` + portal konkretnego sądu | deterministyczny GET po sygnaturze; portal lokalny rozstrzyga AMBIGUOUS |
  | **NSA/WSA** | **`orzeczenia.nsa.gov.pl` / CBOSA** | **fresh-probe → direct HTML: `POST /cbo/search` → sesyjna paginacja `/cbo/find?p=N` → `/doc/{ID}` → exact-match**; implementacja: `shared/CBOSA-ADAPTER.md` + `tools/cbosa_parser.py`. Gdy direct CBOSA niedostępna → `shared/SYGNATURY.md` V-SYG-0.5 |
  | SAOS | `saos.org.pl` | discovery / kontrola krzyżowa wg okna pokrycia; nie zastępuje źródła rozstrzygającego |
  
  ⛔ **Adapter/konektor nie ma własnego RZĘDU.** RZĄD dziedziczy treść ze
  źródła docelowego. MCP/HTML/parser to wyłącznie kanał transportowy.

  ### CBOSA — provenance kanału ≠ status weryfikacji

Nie utożsamiaj „mam treść strony” z „origin odpowiedział teraz”. Pole
`access_mode` opisuje PROVENANCE techniczne i jest niezależne od dwóch
kanonicznych znaczników śladu (`✅ [VER]` / `⚠️ [NIEWERYFIKOWANE]`).

| access_mode | Znaczenie | Status śladu bez dodatkowego dowodu |
|---|---|---|
| `DIRECT_LIVE` | bieżący request do originu zwrócił właściwy dokument | może uzyskać ✅ po exact-match i kontroli treści |
| `CRAWLED_OR_INDEXED` | kopia/snapshot oficjalnego URL z retrieval/crawlera; brak dowodu bieżącego połączenia | ⚠️ + jawne provenance |
| `DIRECT_UNAVAILABLE` | 5xx / timeout / connection failure w tym runtime | ⚠️ |
| `POLICY_BLOCKED` | blokada narzędzia/polityki | ⚠️ |

⛔ **Nie twórz piątego statusu `[SNAPSHOT]`.** Snapshot zapisuj jako pole
provenance, np. `⚠️ [NIEWERYFIKOWANE] {access_mode=CRAWLED_OR_INDEXED, content_scope=METADATA_SENTENCE}`.

✅ Kanał snapshotowy jest wartościowy badawczo. Jeżeli host retrieval przekazuje
oficjalny dokument `orzeczenia.nsa.gov.pl/doc/{ID}` po POST-CHECK HOSTA i
exact-match, wolno odczytać i analizować faktycznie dostępną:
- metrykę;
- sentencję;
- uzasadnienie, jeśli jest obecne; kompletność oznacz osobno.

Pomiar funkcjonalny 2026-09-14 na 10 realnych sygnaturach: wszystkie 10
dostępnych oficjalnych snapshotów miało co najmniej metrykę + sentencję; 5
miało potwierdzalnie pełne uzasadnienie, 2 uzasadnienie bez dowodu kompletności,
3 tylko metrykę + sentencję. To nie jest estymacja pokrycia całej bazy.

⛔ Snapshot nie przechodzi samodzielnie bramki finalnego materiału do pisma
procesowego jako „zweryfikowany online”. Do ✅ [VER] potrzebny jest
`DIRECT_LIVE` albo niezależne bieżące potwierdzenie w oficjalnym kanale.

⛔ Operator `site:` nie jest kontrolą domeny. Obowiązkowy POST-CHECK pełnego
hostname i ścieżki opisuje V-SYG-0.5. Wynik z innego hosta odpada nawet wtedy,
gdy wyszukiwarka zwróciła go na zapytanie z `site:orzeczenia.nsa.gov.pl`.
⛔ **CBOSA — granica wnioskowania:** `FOUND` wymaga exact-match po
  normalizacji. Niepełna paginacja, nierozpoznany licznik, zmiana krytycznej
  struktury HTML, przerwany transport albo błąd choć jednego kandydata =
  `OUT_OF_SCOPE`, nigdy `NOT_FOUND`. Gdy dokument jest kompletny, ale
  portal nie publikuje sekcji uzasadnienia, wolno użyć metryki i sentencji;
  tezy z uzasadnienia są zakazane (`reasoning_available=False`).
  
  Pełny kontrakt statusów: `shared/SYGNATURY.md`; kanały:
  `shared/DOSTEP-MASZYNOWY-API.md`; hard gate:
  `shared/PRAWO-HARDGATE-ORZECZENIA.md`.
- Orzecznictwo i decyzje ORGANÓW (2A, ta sama moc dowodowa co bazy sądowe
  w zakresie ISTNIENIA rozstrzygnięcia): orzeczenia.uodo.gov.pl,
  orzeczenia.uzp.gov.pl (KIO), bip.uke.gov.pl, decyzje.uokik.gov.pl,
  eureka.mf.gov.pl (interpretacje i wiążące informacje KAS).
  ⛔ Stan dostępu maszynowego, ograniczenia i zastrzeżenia każdej z tych baz:
  `shared/DOSTEP-MASZYNOWY-API.md` — to jest ŹRÓDŁO OPERACYJNE i leży
  w `required_modules` routera, więc da się je wczytać z produkcji.
  ⚠️ `audyt-systemu-v4/references/PORTALE-ORZECZNICZE-API.md` niesie surowy
  materiał dowodowy pomiaru i **nie jest osiągalny ze ścieżki produkcyjnej** —
  `audyt-systemu-v4` nie występuje w `dependencies.requires` żadnego skilla
  produkcyjnego (F-160). Odsyła się do niego jako do dowodu, nigdy jako do
  instrukcji. Kilka z tych baz samo
  zastrzega, że NIE jest zbiorem urzędowym — to nie odbiera im RZĘDU 2A dla
  ustalenia istnienia rozstrzygnięcia, ale zabrania traktowania ich jak
  publikatora.
- **Interpretacje i stanowiska organów** (dodane 2026-09-01f):
  `eureka.mf.gov.pl` — interpretacje indywidualne i ogólne, WIS/WIA (KAS);
  **BIP urzędu obsługującego Głównego Inspektora Pracy** — interpretacje
  indywidualne GIP co do tego, czy stosunek prawny jest stosunkiem pracy
  (art. 14b ustawy o PIP, dodany ustawą Dz.U. 2026 poz. 473, w życie
  2026-07-08; obowiązek publikacji — art. 14b ust. 15) ✅ [VER:
  api.sejm.gov.pl/eli → DU/2026/473/text.pdf, 2026-09-01].
  ⛔ Interpretacja organu NIE jest źródłem prawa i nie zastępuje brzmienia
  przepisu — jest dowodem stanowiska organu i tak wolno ją powołać.
- **Decyzje Prezesa UODO — `orzeczenia.uodo.gov.pl`** (dodane 2026-09-04, F-158)
  — RZĄD 2A. ⭐ **Jedyny polski organ z potwierdzonym, udokumentowanym
  publicznym REST API do własnych rozstrzygnięć.** Specyfikacja OpenAPI 3.1
  pod `/api-doc/schemas/openapi.yml`; łańcuch wyszukiwanie → metadane → pełna
  treść XML zmierzony end-to-end 2026-09-04 (baza `/api`, dokument oddany
  jako 118 kB XML). Wywołania: `shared/DOSTEP-MASZYNOWY-API.md` §3;
  dowód pomiaru (materiał audytowy, poza ścieżką produkcyjną — F-160):
  `audyt-systemu-v4/references/PORTALE-ORZECZNICZE-API.md` §7.6.
  ⛔ Decyzja organu nadzorczego NIE jest źródłem prawa — powołuje się ją jako
  rozstrzygnięcie organu, nie jako brzmienie przepisu.
- **Rejestry urzędowe i publikatory ogłoszeń** (dodane 2026-09-01f) — RZĄD 2A
  dla ustalenia FAKTU wpisu, nigdy dla brzmienia przepisu:
  `api-krs.ms.gov.pl` i `wyszukiwarka-krs.ms.gov.pl` (KRS),
  `krz.ms.gov.pl` (Krajowy Rejestr Zadłużonych — upadłość, restrukturyzacja,
  umorzone egzekucje; kluczowy dla DR-02), `ekrs.ms.gov.pl/rdf/pd`
  (sprawozdania finansowe), `ekw.ms.gov.pl` (księgi wieczyste),
  `dane.biznes.gov.pl` (CEIDG), `api.stat.gov.pl` (REGON/BIR),
  `sudop.uokik.gov.pl` (pomoc publiczna i de minimis),
  Biuletyn Zamówień Publicznych — `ezamowienia.gov.pl` / `bzp.uzp.gov.pl`.
- **Materiały legislacyjne** (dodane 2026-09-01f) — `legislacja.rcl.gov.pl`
  (projekty rządowe, uzasadnienia, uzgodnienia) oraz `api.sejm.gov.pl/sejm/...`
  (druki sejmowe, przebieg prac).
  ⛔⛔ To NIE są źródła prawa i NIE wolno z nich cytować brzmienia — projekt
  nie jest aktem. Dopuszczalna rola: wykładnia celowościowa i ustalenie, czy
  zmiana jest w toku. Powołanie zawsze z jawnym słowem „projekt".
- LEX (sip.lex.pl) i Legalis (sip.legalis.pl) jako ŹRÓDŁO-2 dla BRZMIENIA
  przepisu (E-3), przy BRAKU-AKTU w RZĘDZIE 1 i gdy kancelaria posiada aktywną
  licencję — nie staje się przez to RZĘDEM 1, zgodnie z `shared/PRAWO-HARDGATE.md`.

**2B — duże, uznane portale prawnicze/branżowe (komentarz/interpretacja,
znacznik 📚 [ŹRÓDŁO POMOCNICZE — RZĄD 2: ...], NIGDY brzmienie przepisu ani
dowód istnienia orzeczenia):** lista przykładowa, nie zamknięta:

- prawo.pl (Wolters Kluwer — portal informacyjny)
- lex.pl / sip.lex.pl (Wolters Kluwer LEX — w roli komentarza/glosy, nie tekstu)
- legalis.pl / sip.legalis.pl (C.H.Beck — w roli komentarza/monografii, nie tekstu)
- rp.pl (Rzeczpospolita, dział Prawo)
- infor.pl, lexlege.pl, arslege.pl — portale informacyjno-branżowe z
  systematyczną redakcją
- gazetaprawna.pl (Dziennik Gazeta Prawna)
- kadry.infor.pl (prawo pracy — komentarze praktyczne)
- poradnikprzedsiebiorcy.pl (prawo gospodarcze/podatkowe dla przedsiębiorców)
- money.pl (dział Prawo/Podatki)
- gofin.pl (Wydawnictwo Podatkowe GOFIN — podatki, rachunkowość, prawo pracy)
- standardyprawa.pl — agregator orzeczeń/komentarzy przy przepisach (redakcja
  tematyczna, aktualizowana)
- biznes.gov.pl — wyłącznie treści poradnikowe/informacyjne (odróżnij od
  aktów prawnych i oficjalnych interpretacji organów — te, gdy dostępne
  bezpośrednio na stronach urzędowych, np. podatki.gov.pl/eureka, należą
  do Rzędu 1/2A, nie do tej listy)
- inne duże portale o podobnym profilu: redakcja zawodowa/wydawnicza,
  systematyczna aktualizacja po nowelizacjach, rozpoznawalna marka —
  kryterium przynależności do 2B, nie do Rzędu 3.

### ⛔ OSTRZEŻENIE O WERSJACH ARCHIWALNYCH (dodano 2026-08-23, v1.4)

Portale 2B utrzymują **historyczne wersje czasowe artykułów pod tym samym
numerem**, często pod URL-em z parametrem daty. Wyszukiwarka potrafi zwrócić
wersję archiwalną bez żadnego widocznego ostrzeżenia.

Przykład zweryfikowany 2026-08-23: `przepisy.gofin.pl` zwrócił w jednym wyniku
brzmienie art. 113 KRO sprzed nowelizacji z 2008 r. („sąd opiekuńczy zakaże
rodzicom pozbawionym władzy rodzicielskiej osobistej styczności z dzieckiem")
obok brzmienia aktualnego — spod adresu z segmentem `20100801`.

⛔ Skutek dla procedury: **krzyżowanie dwóch portali 2B NIE jest wystarczającym
zabezpieczeniem**, jeśli oba trafią w ten sam odcinek czasu. Rozstrzyga
znacznik tekstu jednolitego widoczny NA STRONIE (np. `Dz.U.2026.0.236 t.j.`)
porównany z numerem t.j. potwierdzonym w indeksie RZĘDU 1. To jest warunek K-3
statusu 🟨 KOTWICA URZĘDOWA w `shared/PRAWO-HARDGATE.md`.

Kryterium 2B vs Rząd 3: redakcja zawodowa + rozpoznawalna marka wydawnicza/
medialna + praktyka regularnej aktualizacji treści po zmianach przepisów →
niższe ryzyko dezaktualizacji niż Rząd 3, ale nadal NIE jest to wykładnia
wiążąca — zawsze 📚, nigdy ✅ [VER].

Ten rząd dotyczy WYŁĄCZNIE brzmienia przepisu — obowiązuje tu
`shared/PRAWO-HARDGATE.md` bez wyjątków.

## RZĄD 3 — TRZECIORZĘDNE (WYSOKIE RYZYKO DEZAKTUALIZACJI)

Strony indywidualnych prawników/kancelarii, blogi eksperckie, organizacje
NGO, fora, poradniki bez redakcji wydawniczej.

Obejmuje: strony własne adwokatów/radców/kancelarii (np. indywidualne
kancelarie adwokackie identyfikowalne po nazwisku prawnika w domenie lub
podtytule), blogi prawnicze, publikacje NGO, fora internetowe, poradniki
bez wskazanej redakcji lub daty aktualizacji. Cecha wspólna uzasadniająca
niższy rząd niż 2B: brak systematycznej redakcji wydawniczej i brak
gwarancji aktualizacji treści po nowelizacji — wpis mógł powstać przed
zmianą przepisu i nigdy nie zostać poprawiony.

**Przykłady typowego wzorca domeny RZĄD 3** (rozpoznawalne po nazwisku
prawnika, nazwie kancelarii lub ogólnym profilu "porady prawne"): strony
zawierające w adresie/nazwie nazwisko konkretnego adwokata/radcy, domeny
w stylu "adwokat-[miasto/nazwisko].pl", "kancelaria-[nazwisko].pl", ogólne
serwisy typu "sprawy-karne.biz.pl", "prawoity.pl" i podobne bez wskazanej
redakcji wydawniczej — lista nie jest zamknięta, kryterium decyduje ZAWSZE
brak redakcji + brak gwarancji aktualizacji, nie sama nazwa domeny.

> ⛔ **ZASADA OTWARTEJ LISTY (dodana 2026-07-24e, na wyraźne polecenie
> użytkownika):** brak wpisu danej domeny w tym pliku lub w
> `shared/PORTALE-BRANZOWE-RZAD-2B.md` NIE JEST przeszkodą do jej
> zacytowania. Rejestry te są przykładowe i pomocnicze (podpowiadają,
> który portal przeszukać przy danej dziedzinie) — nie są zamkniętą
> listą dopuszczonych źródeł ani bramką blokującą. Strona małej,
> nieznanej wcześniej kancelarii lub nowy blog prawniczy KWALIFIKUJE SIĘ
> od razu jako Rząd 3 na podstawie kryteriów powyżej (brak redakcji
> zawodowej + brak gwarancji aktualizacji), bez konieczności
> wcześniejszego dopisania jej do żadnego rejestru. Jedynym wymogiem
> jest przejście przez zasady dodatkowe dla Rzędu 3 poniżej (data
> publikacji, krzyżowanie z Rzędem 1/2, oznaczenie "⚠️ NIEPOTWIERDZONE"
> gdy krzyżowanie niemożliwe) — te same, proporcjonalne do ryzyka
> wymogi weryfikacji, które i tak obowiązują KAŻDE źródło Rzędu 3,
> znane czy nowe. Ta sama logika (brak rejestracji ≠ zakaz cytowania,
> tylko obowiązek weryfikacji) dotyczy analogicznie sekcji 3B (próbki
> nexto.pl i podobnych) — tam kryterium 3B-ii (Beck/Kluwer) także nie
> wymaga wcześniejszego wpisu konkretnego tytułu w żadnym rejestrze,
> wystarczy identyfikacja wydawnictwa w samej próbce.

### Zasady dodatkowe dla Rzędu 3 (ponad ogólny zakaz mieszania ról niżej)

```
1. Sprawdź datę publikacji/ostatniej aktualizacji treści.
   Brak daty lub data > 24 miesiące wstecz → dodaj ostrzeżenie
   "⚠️ możliwa dezaktualizacja — brak/dawna data publikacji".
2. NIGDY nie cytuj twierdzenia z Rzędu 3 jako samodzielnej podstawy —
   zawsze skrzyżuj z Rzędem 1 (tekst) lub 2A (orzecznictwo) przed użyciem.
   Jeśli nie da się skrzyżować (np. brak czasu/dostępu) → oznacz
   "⚠️ NIEPOTWIERDZONE W ŹRÓDLE WYŻSZEGO RZĘDU" i nie buduj na tym wniosku.
3. Dozwolone wyłącznie jako inspiracja do dalszego wyszukiwania (podobnie do
   BRAMKI WTÓRNE-ŹRÓDŁO-STOP dla orzeczeń w `shared/PRAWO-HARDGATE.md`) —
   nigdy jako ostateczne potwierdzenie stanu prawnego.
```

Uzupełniająco do Rzędu 1 (tekst) i Rzędu 2 (orzecznictwo/LEX-Legalis-tekst/
duże portale) — analiza MOŻE sięgać po Rząd 3, gdy wzbogaca kontekst
praktyczny lub wskazuje trop do dalszej weryfikacji, ale ZAWSZE z
zastrzeżeniami powyżej.

### 3B — Próbki/fragmenty książek z księgarni cyfrowych (np. nexto.pl)

> Dodane na wyraźne polecenie użytkownika, po odróżnieniu tego przypadku
> od flagi F-12 (`audyt-systemu-v4/references/WARN-OTWARTE.md`), która
> dotyczy INNEGO zjawiska: pełnych, nieautoryzowanych plików PDF pod
> ścieżką `.../free/[hash].pdf`. TEN wpis dotyczy wyłącznie LEGALNYCH,
> wydawniczo udostępnionych PRÓBEK (fragment tekstu + spis treści,
> ograniczona liczba stron) — standardowej funkcji księgarni cyfrowych
> (nexto.pl i platformy o analogicznym modelu, np. virtualo, woblink,
> publio, ibuk).
>
> **Uzupełnienie 2026-07-24b** (na uwagę użytkownika): kryterium
> przynależności do Rzędu 2B w tym pliku to "redakcja zawodowa +
> rozpoznawalna marka wydawnicza + praktyka aktualizacji" — NIE sam
> kanał dystrybucji. C.H.Beck i Wolters Kluwer są już uznane w Rzędzie
> 2B (patrz wyżej: legalis.pl/sip.legalis.pl, lex.pl/sip.lex.pl), ale
> przez ICH WŁASNE portale. Nexto jest cudzym kanałem sprzedaży TEJ
> SAMEJ treści — dlatego rozróżnienie poniżej: 3B-i (nieustalone/inne
> wydawnictwo → Rząd 3) i 3B-ii (jednoznacznie Beck/Kluwer → Rząd
> 2B-równoważne tej marki).

**Wspólne dla obu przypadków** — próbka NIGDY nie pełni roli Rzędu 1/2A
(nie potwierdza brzmienia przepisu ani istnienia orzeczenia), niezależnie
od tego, który wydawca:

```
1. KAŻDY cytat/parafraza z takiej próbki musi być oznaczony jako
   FRAGMENT/PRÓBKA, nigdy jako pełna treść dzieła — próbka z definicji
   pokazuje tylko część książki (zwykle spis treści + pierwsze strony
   rozdziału), więc twierdzenie zbudowane na próbce może pomijać
   dalszy, niewidoczny kontekst autora. Nie ekstrapoluj poza to, co
   faktycznie widoczne w próbce. Dotyczy to RÓWNIEŻ próbek Beck/Kluwer —
   status wydawnictwa podnosi WIARYGODNOŚĆ treści, ale nie zmienia faktu,
   że widoczny jest tylko fragment.
2. Strona z próbką na nexto.pl (i analogicznych platformach) zawiera
   zwykle wewnętrzną notatkę wydawcy/twórcy o zakazie publikacji treści
   w internecie i o dozwolonym cytowaniu bez zmiany treści — ta notatka
   NIE blokuje cytowania w rozumieniu prawa cytatu (krótki cytat z
   podaniem źródła), ale POTWIERDZA, że wolno przywołać wyłącznie
   krótki, dosłownie niezmieniony fragment, nigdy odtworzyć większą
   część próbki ani całość.
3. ⚠️ WAŻNOŚĆ LINKU — link do konkretnej próbki nie jest trwały:
   wydawca/platforma może zmienić zakres widocznych stron, wycofać
   próbkę, zmienić URL po aktualizacji katalogu, lub zmienić edycję
   książki. Przy KAŻDYM użyciu linku do próbki:
   a) zweryfikuj świeżo przez web_fetch, że link nadal działa i nadal
      pokazuje ten sam fragment, zanim podasz go użytkownikowi;
   b) jeśli link nie działa/przekierowuje/zwraca inną treść — nie
      podawaj go jako źródła, zaznacz "⚠️ link do próbki niedostępny
      w momencie weryfikacji";
   c) NIE zakładaj trwałości linku między sesjami — każda nowa sesja
      wymaga ponownej weryfikacji, nawet jeśli link działał wcześniej.
4. ⚠️ AKTUALNOŚĆ WYDANIA — w odróżnieniu od portalu (2B, aktualizowany
   na bieżąco), książka jest zamrożona na dacie wydania. Sprawdź rok
   wydania/numer edycji widoczny w próbce i skrzyżuj z ewentualnymi
   nowelizacjami przepisu od tej daty (np. przez ELI `/references` / historię aktu) —
   jeśli przepis był nowelizowany po dacie wydania, komentarz może być
   nieaktualny mimo renomy wydawnictwa; oznacz to wprost.
5. Odróżnij WYRAŹNIE od F-12: jeśli podczas przeglądania próbki
   natrafisz na plik pod wzorcem `.../free/[hash].pdf` udostępniający
   PEŁNĄ, płatną treść komentarza (nie ograniczoną próbkę) — to NIE
   jest ten przypadek, tylko wzorzec z F-12; postępuj wg zasad z
   `audyt-systemu-v4/references/WARN-OTWARTE.md` (flaga F-12), NIE
   cytuj takiego pliku jako źródła i nie traktuj go jak zwykłej próbki.
```

**3B-i — wydawnictwo nieustalone lub inne niż Beck/Kluwer → Rząd 3**

Traktuj jak zwykły Rząd 3 (wymóg krzyżowania z Rzędem 1/2, ryzyko
dezaktualizacji, zakaz samodzielnej podstawy) — plus zasady 1–5 powyżej.

Znacznik:

```
⚠️📚 [ŹRÓDŁO POMOCNICZE — RZĄD 3, PRÓBKA: nexto.pl (lub inna platforma),
wydawnictwo jeśli znane, tytuł/autor/wydanie, data weryfikacji linku]
— FRAGMENT/PRÓBKA WYDAWNICZA, nie pełna treść dzieła; link zweryfikowany
web_fetch w tej sesji; wymaga potwierdzenia w Rzędzie 1/2 jak każdy Rząd 3
```

**3B-ii — jednoznacznie identyfikowalne wydawnictwo C.H.Beck lub Wolters
Kluwer (widoczne w próbce logo/stopka wydawcy, seria wydawnicza, ISBN
przypisany do tych wydawnictw) → Rząd 2B-równoważne**

Dziedziczy status Rzędu 2B tej samej marki co legalis.pl (Beck) i
lex.pl/sip.lex.pl (Kluwer) — "w roli komentarza/monografii, nie tekstu"
— pod warunkiem spełnienia zasad 1–5 powyżej (fragment, notatka wydawcy,
ważność linku, aktualność wydania, odróżnienie od F-12). Redakcja
wydawnicza uzasadnia niższe ryzyko merytoryczne treści niż typowy
Rząd 3, ale NIE zwalnia z obowiązków fragmentu/linku/aktualności — to są
zastrzeżenia o innej naturze (kompletność i trwałość źródła), nie o
jakości wydawniczej.

Znacznik:

```
📚 [ŹRÓDŁO POMOCNICZE — RZĄD 2B-RÓWNOWAŻNE (nexto.pl, wydawnictwo:
C.H.Beck/Wolters Kluwer), PRÓBKA: tytuł/autor/wydanie, data weryfikacji
linku] — FRAGMENT/PRÓBKA WYDAWNICZA (nie pełna treść), status 2B
dziedziczony po wydawnictwie identyfikowalnym w próbce; sprawdzona
aktualność wydania względem nowelizacji; link zweryfikowany web_fetch
w tej sesji; NIGDY brzmienie przepisu ani dowód istnienia orzeczenia
```

---

## ⛔ ZAKAZ MIESZANIA RZĘDÓW

```
- Dla BRZMIENIA przepisu → wyłącznie Rząd 1 lub Rząd 2A (LEX/Legalis-tekst,
  przy licencji) — Rząd 2B i Rząd 3 nigdy nie pełnią tej roli.
- Dla ISTNIENIA sygnatury orzeczenia → wyłącznie Rząd 2A (oficjalna baza
  sądowa, BRAMKA WTÓRNE-ŹRÓDŁO-STOP z `shared/PRAWO-HARDGATE.md`) — Rząd 2B
  i Rząd 3 nigdy nie potwierdzają istnienia orzeczenia, tylko wskazują trop.
- Dla INTERPRETACJI DOKTRYNALNEJ (np. rozszerzenie zakresu przepisu na
  podstawie poglądu prawniczego, nie samego brzmienia ustawy) → Rząd 2B/3
  wolno cytować WYŁĄCZNIE jako pogląd/informację pomocniczą, z jawnym
  znacznikiem, NIGDY jako ostateczne potwierdzenie wykładni.
```

## ZNACZNIK OBOWIĄZKOWY

Każdy fragment/link pochodzący z Rzędu 2B lub Rzędu 3 oznacz:

```
📚 [ŹRÓDŁO POMOCNICZE — RZĄD 2: nazwa portalu, autor jeśli podany, data]
— pogląd doktrynalny/informacyjny, nie wykładnia wiążąca

⚠️📚 [ŹRÓDŁO POMOCNICZE — RZĄD 3: nazwa strony/autor, data jeśli znana]
— WYSOKIE RYZYKO DEZAKTUALIZACJI, wymaga potwierdzenia w Rzędzie 1/2
```

Nie myl ze znacznikami HARDGATE / WERYFIKACJA-ŚLAD:

```
✅ [VER: ELI DU/RRRR/NNN, data]                     → Rząd 1, tekst przepisu, wiążący
✅ [VER: sn.pl / orzeczenia.ms.gov.pl / ..., data]   → Rząd 2A, orzeczenie zweryfikowane oficjalnie
✅ [VER: LEX/Legalis, data]                          → Rząd 2A, tekst przepisu (tylko przy licencji)
📚 [ŹRÓDŁO POMOCNICZE — RZĄD 2: portal, data]        → Rząd 2B, duży portal, komentarz/informacja
⚠️📚 [ŹRÓDŁO POMOCNICZE — RZĄD 3: strona/autor, data] → Rząd 3, wysokie ryzyko dezaktualizacji
```

**Integracja z `WERYFIKACJA-ŚLAD.md`:** znacznik RZĄD i znacznik VER/GRADIENT
podaje się RAZEM — RZĄD mówi, jak wiarygodne jest źródło samo w sobie;
VER/GRADIENT mówi, czy i na jakim poziomie faktycznie zweryfikowano treść
wobec tego źródła. Przykład łączony:

```
art. 281 KK — kradzież rozbójnicza wobec osoby trzeciej
  📚 [ŹRÓDŁO POMOCNICZE — RZĄD 3: kdkadwokat.pl, 2020-12-13]
  🟢 [VER-TREŚĆ: kdkadwokat.pl, 2026-07-15] — teza skrzyżowana z brzmieniem
     art. 281 KK (Rząd 1, ELI) — zgodna co do istoty
  🔗 [KOTWICA-TEKSTOWA: kdkadwokat.pl/.../#:~:text=Jako%20kradzie%C5%BC...]
```

## KOLIZJA Z ORZECZNICTWEM

Jeśli pogląd z Rzędu 2B/3 jest sprzeczny ze zweryfikowaną linią orzeczniczą
(Rząd 2A) → wyraźnie zaznacz rozbieżność w raporcie; priorytet
interpretacyjny ma zawsze Rząd 1/2A.

## GDZIE STOSOWAĆ RZĄD 2B / RZĄD 3

- Przy wykładni pojęć nieostrych — jako dodatkowy kontekst, obok (nie
  zamiast) wykładni orzeczniczej; Rząd 3 wyłącznie po skrzyżowaniu z
  Rzędem 1/2A.
- Przy wyjaśnieniach dla laika — komentarze (zwłaszcza 2B) ułatwiają
  przystępne, praktyczne wyjaśnienie.
- W raporcie końcowym — osobna podsekcja "Źródła pomocnicze (Rząd 2B/Rząd 3)",
  oddzielona od "Źródła normatywne i orzecznicze (Rząd 1/2A, zweryfikowane)".

---

## PROCEDURA — GDZIE I KIEDY STOSOWAĆ TEN PLIK

```
STOSUJ przy KAŻDYM linku/URL/kotwicy podanym użytkownikowi, niezależnie
od tego, który skill/moduł generuje odpowiedź:

  KROK H-1: Po otrzymaniu wyniku z web_search/web_fetch → zidentyfikuj
            domenę źródła.
  KROK H-2: Sklasyfikuj wg tabeli wyżej: Rząd 1 / 2A / 2B / 3.
            W razie wątpliwości między 2B a 3 → zastosuj kryterium
            (redakcja zawodowa + rozpoznawalna marka + systematyczna
            aktualizacja = 2B; brak któregokolwiek = 3).
  KROK H-3: Dołącz odpowiedni znacznik (✅/📚/⚠️📚) OBOK znacznika
            VER/GRADIENT z `shared/WERYFIKACJA-SLAD.md` i OBOK ewentualnej
            kotwicy tekstowej z sekcji KOTWICA-TEKSTOWA tamże.
  KROK H-4: Rząd 3 → dodatkowo sprawdź datę (zasada 1 wyżej) i skrzyżuj
            z Rzędem 1/2A (zasada 2 wyżej) przed użyciem jako poparcia tezy.

⛔ ZAKAZ pomijania KROK H-1→H-3 z powodu "to nie jest analiza przepisu,
   tylko cytowanie w innym kontekście" — kategoryzacja dotyczy KAŻDEGO
   linku źródłowego w systemie, nie tylko modułu analizy przepisów.
```
